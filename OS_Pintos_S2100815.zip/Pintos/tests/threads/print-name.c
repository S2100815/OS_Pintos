#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/init.h"

void test_uwe_print_name(void)
{

	printf("UWE You ID: as25-ahmed\n");
	printf("UWE Department: CSCT!\n");
	printf("UWE City: Bristol\n");
	printf("UWE UK\n");

}
void test_print_name(void)
{
	printf("UWE Print Name!\n");
}

"print-name.c" 21 lines. 303 characters
